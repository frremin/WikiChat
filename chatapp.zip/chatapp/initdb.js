// Creates the tables in schema.sql against DATABASE_URL. Run with: npm run initdb
require("dotenv").config();
const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL && process.env.DATABASE_URL.includes("localhost")
    ? false
    : { rejectUnauthorized: false },
});

async function main() {
  const sql = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
  await pool.query(sql);
  console.log("Database schema is ready.");
  await pool.end();
}

main().catch(err => {
  console.error("Failed to initialize database:", err);
  process.exit(1);
});
