require("dotenv").config();
const express = require("express");
const http = require("http");
const path = require("path");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { WebSocketServer } = require("ws");
const { Pool } = require("pg");

const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
const PORT = process.env.PORT || 3000;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL && process.env.DATABASE_URL.includes("localhost")
    ? false
    : { rejectUnauthorized: false },
});

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ---------- Auth helpers ----------

function signToken(user) {
  return jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: "30d" });
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Missing auth token" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (e) {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

// ---------- REST: signup / login ----------

app.post("/api/signup", async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password || username.length < 3 || password.length < 6) {
      return res.status(400).json({ error: "Username (3+ chars) and password (6+ chars) required" });
    }
    const existing = await pool.query("SELECT id FROM users WHERE username = $1", [username]);
    if (existing.rows.length) {
      return res.status(409).json({ error: "Username already taken" });
    }
    const hash = await bcrypt.hash(password, 10);
    const result = await pool.query(
      "INSERT INTO users (username, password_hash) VALUES ($1, $2) RETURNING id, username",
      [username, hash]
    );
    const user = result.rows[0];
    res.json({ token: signToken(user), user });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Signup failed" });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    const result = await pool.query("SELECT * FROM users WHERE username = $1", [username]);
    const row = result.rows[0];
    if (!row) return res.status(401).json({ error: "Invalid username or password" });
    const ok = await bcrypt.compare(password, row.password_hash);
    if (!ok) return res.status(401).json({ error: "Invalid username or password" });
    const user = { id: row.id, username: row.username };
    res.json({ token: signToken(user), user });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Login failed" });
  }
});

// ---------- REST: contacts / history ----------

app.get("/api/users", authMiddleware, async (req, res) => {
  const result = await pool.query(
    "SELECT id, username FROM users WHERE id != $1 ORDER BY username",
    [req.user.id]
  );
  res.json(result.rows);
});

app.get("/api/messages/:otherUserId", authMiddleware, async (req, res) => {
  const otherId = Number(req.params.otherUserId);
  const result = await pool.query(
    `SELECT id, sender_id, receiver_id, content, created_at
     FROM messages
     WHERE (sender_id = $1 AND receiver_id = $2) OR (sender_id = $2 AND receiver_id = $1)
     ORDER BY created_at ASC
     LIMIT 200`,
    [req.user.id, otherId]
  );
  res.json(result.rows);
});

// ---------- Real-time layer ----------

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

// userId -> Set of open sockets (a user could have multiple tabs open)
const connections = new Map();

function addConnection(userId, ws) {
  if (!connections.has(userId)) connections.set(userId, new Set());
  connections.get(userId).add(ws);
}

function removeConnection(userId, ws) {
  const set = connections.get(userId);
  if (!set) return;
  set.delete(ws);
  if (set.size === 0) connections.delete(userId);
}

function sendToUser(userId, payload) {
  const set = connections.get(userId);
  if (!set) return false;
  const data = JSON.stringify(payload);
  for (const ws of set) {
    if (ws.readyState === ws.OPEN) ws.send(data);
  }
  return set.size > 0;
}

wss.on("connection", (ws, req) => {
  // Auth via ?token=... query param on the WebSocket URL
  const url = new URL(req.url, `http://${req.headers.host}`);
  const token = url.searchParams.get("token");
  let user;
  try {
    user = jwt.verify(token, JWT_SECRET);
  } catch (e) {
    ws.close(4001, "Invalid token");
    return;
  }

  addConnection(user.id, ws);
  ws.send(JSON.stringify({ type: "connected", userId: user.id }));

  ws.on("message", async raw => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return;
    }

    if (msg.type === "chat") {
      const receiverId = Number(msg.receiverId);
      const content = String(msg.content || "").slice(0, 4000).trim();
      if (!receiverId || !content) return;

      try {
        const result = await pool.query(
          `INSERT INTO messages (sender_id, receiver_id, content)
           VALUES ($1, $2, $3)
           RETURNING id, sender_id, receiver_id, content, created_at`,
          [user.id, receiverId, content]
        );
        const saved = result.rows[0];

        // Deliver to receiver if online, and echo back to sender (for other tabs)
        sendToUser(receiverId, { type: "chat", message: saved });
        sendToUser(user.id, { type: "chat", message: saved });
      } catch (e) {
        console.error("Failed to save/deliver message:", e);
      }
    }

    if (msg.type === "typing") {
      const receiverId = Number(msg.receiverId);
      if (receiverId) {
        sendToUser(receiverId, { type: "typing", from: user.id });
      }
    }
  });

  ws.on("close", () => removeConnection(user.id, ws));
});

server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
