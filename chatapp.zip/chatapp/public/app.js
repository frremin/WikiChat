(() => {
  const API = ""; // same origin
  let token = localStorage.getItem("chatapp_token");
  let me = JSON.parse(localStorage.getItem("chatapp_user") || "null");
  let ws = null;
  let contacts = [];
  let activeContact = null;
  let typingTimeout = null;

  const el = id => document.getElementById(id);
  const authScreen = el("authScreen");
  const chatScreen = el("chatScreen");

  // ---------- Tabs ----------
  document.querySelectorAll(".tabBtn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tabBtn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const tab = btn.dataset.tab;
      el("loginForm").style.display = tab === "login" ? "flex" : "none";
      el("signupForm").style.display = tab === "signup" ? "flex" : "none";
      el("authError").textContent = "";
    });
  });

  // ---------- Auth ----------
  async function apiCall(path, opts = {}) {
    const res = await fetch(API + path, {
      ...opts,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: "Bearer " + token } : {}),
        ...(opts.headers || {}),
      },
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Request failed");
    return data;
  }

  el("loginForm").addEventListener("submit", async e => {
    e.preventDefault();
    el("authError").textContent = "";
    try {
      const data = await apiCall("/api/login", {
        method: "POST",
        body: JSON.stringify({
          username: el("loginUsername").value.trim(),
          password: el("loginPassword").value,
        }),
      });
      onAuthSuccess(data);
    } catch (err) {
      el("authError").textContent = err.message;
    }
  });

  el("signupForm").addEventListener("submit", async e => {
    e.preventDefault();
    el("authError").textContent = "";
    try {
      const data = await apiCall("/api/signup", {
        method: "POST",
        body: JSON.stringify({
          username: el("signupUsername").value.trim(),
          password: el("signupPassword").value,
        }),
      });
      onAuthSuccess(data);
    } catch (err) {
      el("authError").textContent = err.message;
    }
  });

  function onAuthSuccess(data) {
    token = data.token;
    me = data.user;
    localStorage.setItem("chatapp_token", token);
    localStorage.setItem("chatapp_user", JSON.stringify(me));
    enterChat();
  }

  el("logoutBtn").addEventListener("click", () => {
    localStorage.removeItem("chatapp_token");
    localStorage.removeItem("chatapp_user");
    token = null; me = null; activeContact = null;
    if (ws) ws.close();
    chatScreen.style.display = "none";
    authScreen.style.display = "flex";
  });

  // ---------- Enter chat ----------
  async function enterChat() {
    authScreen.style.display = "none";
    chatScreen.style.display = "flex";
    el("meLabel").textContent = me.username;
    connectSocket();
    await loadContacts();
  }

  async function loadContacts() {
    contacts = await apiCall("/api/users");
    renderContacts();
  }

  function renderContacts() {
    const list = el("contactList");
    list.innerHTML = "";
    contacts.forEach(c => {
      const item = document.createElement("div");
      item.className = "contactItem" + (activeContact && activeContact.id === c.id ? " active" : "");
      item.innerHTML = `<div class="avatar">${c.username[0].toUpperCase()}</div><div class="contactName">${escapeHtml(c.username)}</div>`;
      item.addEventListener("click", () => selectContact(c));
      list.appendChild(item);
    });
    if (contacts.length === 0) {
      list.innerHTML = `<div style="padding:16px; color:var(--text-dim); font-size:13px;">No other users yet. Ask a friend to sign up!</div>`;
    }
  }

  async function selectContact(c) {
    activeContact = c;
    renderContacts();
    el("chatHeader").textContent = c.username;
    el("messageInput").disabled = false;
    document.querySelector(".messageForm button").disabled = false;
    document.querySelector(".chatPane").style.display = "flex";
    const history = await apiCall(`/api/messages/${c.id}`);
    renderMessages(history);
  }

  function renderMessages(msgs) {
    const box = el("messages");
    box.innerHTML = "";
    msgs.forEach(m => appendBubble(m));
    box.scrollTop = box.scrollHeight;
  }

  function appendBubble(m) {
    const box = el("messages");
    const mine = m.sender_id === me.id;
    const div = document.createElement("div");
    div.className = "bubble " + (mine ? "out" : "in");
    const time = new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    div.innerHTML = `${escapeHtml(m.content)}<span class="time">${time}</span>`;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
  }

  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
  }

  // ---------- WebSocket ----------
  function connectSocket() {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    ws = new WebSocket(`${proto}//${location.host}/ws?token=${encodeURIComponent(token)}`);

    ws.addEventListener("message", ev => {
      const msg = JSON.parse(ev.data);
      if (msg.type === "chat") {
        const m = msg.message;
        const relevant = activeContact && (m.sender_id === activeContact.id || m.receiver_id === activeContact.id);
        if (relevant) appendBubble(m);
      }
      if (msg.type === "typing") {
        if (activeContact && msg.from === activeContact.id) {
          el("typingIndicator").textContent = `${activeContact.username} is typing…`;
          clearTimeout(typingTimeout);
          typingTimeout = setTimeout(() => (el("typingIndicator").textContent = ""), 1500);
        }
      }
    });

    ws.addEventListener("close", () => {
      // simple auto-reconnect
      setTimeout(() => { if (token) connectSocket(); }, 1500);
    });
  }

  el("messageForm").addEventListener("submit", e => {
    e.preventDefault();
    if (!activeContact) return;
    const input = el("messageInput");
    const content = input.value.trim();
    if (!content || !ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: "chat", receiverId: activeContact.id, content }));
    input.value = "";
  });

  let lastTypingSent = 0;
  el("messageInput").addEventListener("input", () => {
    if (!activeContact || !ws || ws.readyState !== WebSocket.OPEN) return;
    const now = Date.now();
    if (now - lastTypingSent > 800) {
      ws.send(JSON.stringify({ type: "typing", receiverId: activeContact.id }));
      lastTypingSent = now;
    }
  });

  // Periodically refresh contact list so newly signed-up users appear without a reload
  setInterval(() => { if (token) loadContacts().catch(() => {}); }, 8000);

  // ---------- Boot ----------
  if (token && me) {
    enterChat();
  }
})();
